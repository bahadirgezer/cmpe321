.headers on
.mode tabs
SELECT D.Director_Name, G.Type 
FROM FILM F 
INNER JOIN DIRECTOR D ON F.Director=D.Director_ID 
INNER JOIN GENRE G ON F.Genre=G.Genre_ID 
WHERE F.Budget = (SELECT MAX(F2.Budget) FROM FILM F2);
-- The inner query finds the film with the highest budget,
-- which is then used in the outer query to find the film(s) with that budget.
-- Then, the director and genre of the film(s) with the highest budget are selected.