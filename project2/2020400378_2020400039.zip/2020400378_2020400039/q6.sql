SELECT G.Type, COUNT(*) AS Film_Count FROM FILM F 
INNER JOIN GENRE G ON F.Genre = G.Genre_ID
GROUP BY G.Type
ORDER BY Film_Count DESC; 
-- Group by genre type and count the number of films in each genre, 
-- then order by the number of films in each genre in descending order.