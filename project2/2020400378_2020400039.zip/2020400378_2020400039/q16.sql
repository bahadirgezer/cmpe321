SELECT D.Director_Name, AVG(F.Budget) AS Avg_Budget FROM FILM F INNER JOIN DIRECTOR D
ON F.Director = D.Director_ID
GROUP BY D.Director_Name
ORDER BY AVG(F.Budget) DESC;
-- The query finds the average budget of each director and orders the directors by the average budget in descending order.