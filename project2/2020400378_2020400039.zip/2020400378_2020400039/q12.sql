SELECT D.Director_Name, F.Release_Year, F.Budget
FROM DIRECTOR D INNER JOIN FILM F ON D.Director_ID = F.Director
WHERE F.Budget = (
    SELECT MAX(F1.Budget) FROM FILM F1
    WHERE F1.Release_Year = F.Release_Year
)
ORDER BY F.Release_Year ASC;
-- Find the director who has directed the film with the highest budget in each year.
-- The innermost select statement selects the maximum budget of all films that were
-- released in the same year as the film that is being selected.