SELECT F1.Title, F1.Release_Year, F1.Budget FROM FILM F1
WHERE F1.Release_Year = (
SELECT F2.Release_Year FROM FILM F2
WHERE F2.Title = 'The Godfather'
)
AND F1.Budget > (
SELECT F3.Budget FROM FILM F3
WHERE F3.Title = 'The Godfather'
);
-- The release year and the budget of "The Godfather" are found
-- in the inner select statements. The outer select statement then
-- selects the title, release year and budget of all films that have
-- the same release year as "the Godfather" and a budget greater than
-- "The Godfather"s budget.