SELECT F.Title, D.Director_Name, F.Release_Year FROM FILM F INNER JOIN DIRECTOR D ON F.Director = D.Director_ID
WHERE F.Film_ID IN
(SELECT F1.Film_ID AS ID FROM FILM F1
WHERE F1.Release_Year > 2015
EXCEPT
SELECT F2.Film_ID
FROM FILM F2 INNER JOIN AWARD A ON F2.Film_ID = A.Awarded_Film)
ORDER BY F.Release_Year ASC;
-- In the inner query, the films that were released after 2015 and have not been awarded are selected.
-- The outer query selects the Title, Director_Name and Release_Year of the films according to the selected Film_IDs.