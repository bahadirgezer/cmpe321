SELECT D.Director_Name FROM Director D  
WHERE D.Director_ID IN
(SELECT DISTINCT F2.Director            -- This query is used to get the director IDs of the selected films.
FROM Film F2
WHERE F2.Title IN 
(SELECT DISTINCT F.Title AS TempFilms   -- This query is used to get the titles of the films that got at least 3 distinct awards.
FROM FILM F INNER JOIN                  -- A joint table of awards and films is being used.
AWARD A ON F.Film_ID = A.Awarded_Film   -- The table is grouped by the title of the films having at least 3 distinct awards.
GROUP BY F.Title
HAVING COUNT(*) > 2)
-- In the inner most query the films that got at least 3 distinct awards are selected.
)
-- The director IDs of the selected films are selected in the outer query. (The director names are selected in the outermost query.)
ORDER BY D.Director_Name;
-- The director names are selected by using the director IDs of the selected films and ordered by the director names.