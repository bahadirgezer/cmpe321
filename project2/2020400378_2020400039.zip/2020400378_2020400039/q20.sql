SELECT D.Director_ID AS Director_ID,
       CASE WHEN D.Director_ID IN (SELECT D.Director_ID
                                   FROM DIRECTOR D
                                   LEFT JOIN FILM F ON D.Director_ID = F.Director
                                   LEFT JOIN AWARD A ON F.Film_ID = A.Awarded_Film
                                   WHERE A.Awarded_Film IS NOT NULL
                                   GROUP BY D.Director_ID) THEN 'TRUE' ELSE 'FALSE' END AS Awarded
FROM DIRECTOR D;
-- The inner query finds the directors who have been awarded at least once. 
-- The outer query finds the directors and prints whether they have been awarded or not.
