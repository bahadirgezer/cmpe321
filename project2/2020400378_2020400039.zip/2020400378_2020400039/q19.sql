SELECT * FROM FILM F INNER JOIN
DIRECTOR D ON D.Favorite_Genre = F.Genre
WHERE D.Director_ID = F.Director;
-- Find the films that are the favorite genre of the director who directed them. 