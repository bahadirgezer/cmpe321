SELECT Director_Name, MAX(Film_Count) AS Film_Count FROM (
SELECT D.Director_Name, COUNT(*) AS Film_Count FROM Director D INNER JOIN FILM F ON D.Director_ID = F.Director
GROUP BY D.Director_Name
);
-- The inner query finds the number of films for each director.
-- The outer query find the director with the maximum number of films.