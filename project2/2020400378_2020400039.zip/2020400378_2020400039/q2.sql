SELECT F.Title, D.Director_Name, F.Release_Year 
FROM FILM F
INNER JOIN Director D ON D.Director_ID = F.Director
WHERE F.Release_Year < 2020 
ORDER BY F.Release_Year ASC;
-- Get the title, director (name), and release year of all films released before 2020