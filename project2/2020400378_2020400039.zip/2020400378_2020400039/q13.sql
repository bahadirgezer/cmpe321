
SELECT GT AS Genre, DN AS Director_Name, NumberOfAwards AS Awards 
FROM (SELECT G.Type AS GT, D.Director_Name AS DN, COUNT(*) AS NumberOfAwards FROM GENRE G 
INNER JOIN FILM F ON G.Genre_ID = F.Genre
INNER JOIN AWARD A ON F.Film_ID = A.Awarded_Film
INNER JOIN DIRECTOR D ON F.Director = D.Director_ID
GROUP BY G.Type, D.Director_Name)
WHERE NumberOfAwards = (
    SELECT MAX(NumberOfAwards1) FROM ( 
        SELECT G1.Type AS G1T, D1.Director_Name, COUNT(*) AS NumberOfAwards1 FROM GENRE G1 
        INNER JOIN FILM F1 ON G1.Genre_ID = F1.Genre
        INNER JOIN AWARD A1 ON F1.Film_ID = A1.Awarded_Film
        INNER JOIN DIRECTOR D1 ON F1.Director = D1.Director_ID
        GROUP BY G1.Type, D1.Director_Name)
    WHERE GT = G1T
);
-- The two innermost select statements are used to get the number of awards for each genre and director combination.
-- Both are the same table, but the first one is used to type, director name and number of awards. 
-- The second one is used to get the maximum number of awards for each genre. 