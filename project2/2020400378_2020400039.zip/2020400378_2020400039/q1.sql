SELECT COUNT(*) AS Film_Count FROM Film;
 -- Get the number of films in the database