SELECT Title FROM FILM
EXCEPT 
SELECT F.Title FROM
FILM F INNER JOIN AWARD A ON F.Film_ID = A.Awarded_Film
UNION
SELECT F1.Title FROM
FILM F1
WHERE F1.Director = (
    SELECT D.Director_ID FROM DIRECTOR D
    WHERE D.Director_Name = 'Martin Scorsese'
);
-- The union of the two inner select statements selects all the titles
-- of films that have been awarded an award or have been directed
-- by Martin Scorsese.
-- The except statement then selects all the titles of films that
-- have not been awarded an award and have not been directed by
-- Martin Scorsese.