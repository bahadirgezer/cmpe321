INSERT INTO AWARD (Award_ID, Award_Title, Awarded_Film)
SELECT MAX(A.Award_ID) + 1, 'BU-Best Actor', F.Film_ID
FROM FILM F, AWARD A 
WHERE F.Title='After Sun';
-- Cross join 
-- Three columns are required for the INSERT statement
-- The award ID is the maximum award ID + 1, which is the next available ID
-- The award title is 'BU-Best Actor', given in the description
-- The awarded film is the film with title 'After Sun', given in the description
SELECT * FROM AWARD A WHERE A.Award_ID = (SELECT MAX(A2.Award_ID) FROM AWARD A2);
-- Select the newly inserted award 
DELETE FROM AWARD WHERE Award_ID = (SELECT MAX(A2.Award_ID) FROM AWARD A2);
-- Delete the newly inserted award, so that the database is not modified