SELECT SUM(F.Budget) AS 'Total Price' FROM FILM F;
-- Sum all of all film budgets, display the result as 'Total Price'.