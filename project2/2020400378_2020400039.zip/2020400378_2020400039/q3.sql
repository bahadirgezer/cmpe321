SELECT *
FROM FILM F
WHERE F.Budget = (SELECT MIN(F2.Budget) FROM FILM F2);
-- The inner query finds the film with the lowest budget, 
-- which is then used in the outer query to find the film(s) with that budget. 
