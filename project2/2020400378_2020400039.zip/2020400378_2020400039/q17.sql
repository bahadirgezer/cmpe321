SELECT GT AS Genre_Type, DN AS Director_Name, NumberOfFilms AS Film_Count FROM ( 
    SELECT G.Type AS GT, D.Director_Name AS DN, COUNT(*) AS NumberOfFilms FROM GENRE G 
    INNER JOIN FILM F ON G.Genre_ID = F.Genre
    INNER JOIN DIRECTOR D ON F.Director = D.Director_ID
    GROUP BY G.Type, D.Director_Name
)
-- Select from the table of genres, directors and number of films
WHERE NumberOfFilms = (     
    SELECT MAX(NumberOfFilms1) FROM (
        SELECT G1.Type AS GT1, D1.Director_Name AS DN1, COUNT(*) AS NumberOfFilms1 FROM GENRE G1 
        INNER JOIN FILM F1 ON G1.Genre_ID = F1.Genre
        INNER JOIN DIRECTOR D1 ON F1.Director = D1.Director_ID
        GROUP BY G1.Type, D1.Director_Name
    )
    WHERE GT1 = GT
)
-- Choose the directors who have the maximum number of films for each genre 
AND DN NOT IN (      -- And the directors who have won at least one award        
    SELECT DN2 FROM (  
        SELECT G2.Type AS G2T, D2.Director_Name AS DN2, COUNT(*) AS NumberOfAwards FROM GENRE G2 
        INNER JOIN FILM F2 ON G2.Genre_ID = F2.Genre
        INNER JOIN AWARD A2 ON F2.Film_ID = A2.Awarded_Film
        INNER JOIN DIRECTOR D2 ON F2.Director = D2.Director_ID
        GROUP BY G2.Type, D2.Director_Name)
        -- Select the directors who have not won any award for each genre
    WHERE G2T = GT 
); -- For each genre, select the directors who have won at least one award